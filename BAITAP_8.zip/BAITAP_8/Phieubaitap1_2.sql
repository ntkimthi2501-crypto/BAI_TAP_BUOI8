CREATE TABLE HangSX (
MaHangSX VARCHAR2(10) CONSTRAINT pk_hangsx PRIMARY KEY,
TenHang VARCHAR2(30) NOT NULL,
DiaChi VARCHAR2(50),
SoDT VARCHAR2(15),
Email VARCHAR2(50)
);
CREATE TABLE SanPham (
MaSP VARCHAR2(10) CONSTRAINT pk_sanpham PRIMARY KEY,
MaHangSX VARCHAR2(10) REFERENCES HangSX(MaHangSX),
TenSP VARCHAR2(50) NOT NULL,
SoLuong NUMBER(10),
MauSac VARCHAR2(20),
GiaBan NUMBER(15,2),
DonViTinh VARCHAR2(15),
MoTa CLOB
);
CREATE TABLE NhanVien (
MaNV VARCHAR2(10) CONSTRAINT pk_nhanvien PRIMARY KEY,
TenNV VARCHAR2(50) NOT NULL,
GioiTinh VARCHAR2(10),
DiaChi VARCHAR2(100),
SoDT VARCHAR2(15),
Email VARCHAR2(50),
TenPhong VARCHAR2(30)
);
CREATE TABLE PNhap (
SoHDN VARCHAR2(10) CONSTRAINT pk_pnhap PRIMARY KEY,
NgayNhap DATE,
MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);
CREATE TABLE Nhap (
SoHDN VARCHAR2(10) REFERENCES PNhap(SoHDN),
MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
SoLuongN NUMBER(10),
DonGiaN NUMBER(15,2),
CONSTRAINT pk_nhap PRIMARY KEY (SoHDN, MaSP)
);
CREATE TABLE PXuat (
SoHDX VARCHAR2(10) CONSTRAINT pk_pxuat PRIMARY KEY,
NgayXuat DATE,
MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);
CREATE TABLE Xuat (
SoHDX VARCHAR2(10) REFERENCES PXuat(SoHDX),
MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
SoLuongX NUMBER(10),
CONSTRAINT pk_xuat PRIMARY KEY (SoHDX, MaSP)
);
SET SERVEROUTPUT ON;
--PHIEU BAI TAP 1
CREATE OR REPLACE PROCEDURE sp_NhapHangSX (
    mhsx VARCHAR2, ten VARCHAR2, dc VARCHAR2, dt VARCHAR2, mail VARCHAR2
) AS
    dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO dem FROM HangSX WHERE TenHang = ten;
    IF dem > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ten hang nay da co trong may roi');
    ELSE
        INSERT INTO HangSX VALUES (mhsx, ten, dc, dt, mail);
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Them hang thanh cong');
    END IF;
END;
/
-- TEST:
 EXEC sp_NhapHangSX('H01', 'Samsung', 'Korea', '0123', 'ss@gmail.com');
 EXEC sp_NhapHangSX('H02', 'Samsung', 'Korea', '0123', 'ss@gmail.com');

CREATE OR REPLACE PROCEDURE sp_NhapSP (
    msp VARCHAR2, th VARCHAR2, tsp VARCHAR2, sl NUMBER, ms VARCHAR2, gb NUMBER, dvt VARCHAR2, mt CLOB
) AS
    ma_h VARCHAR2(10);
    dem_sp NUMBER;
BEGIN
    BEGIN
        SELECT MaHangSX INTO ma_h FROM HangSX WHERE TenHang = th;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Khong tim thay ten hang nay');
        RETURN;
    END;

    SELECT COUNT(*) INTO dem_sp FROM SanPham WHERE MaSP = msp;
    IF dem_sp > 0 THEN
        UPDATE SanPham SET MaHangSX = ma_h, TenSP = tsp, SoLuong = sl, MauSac = ms, GiaBan = gb, DonViTinh = dvt, MoTa = mt WHERE MaSP = msp;
        DBMS_OUTPUT.PUT_LINE('Cap nhat san pham xong');
    ELSE
        INSERT INTO SanPham VALUES (msp, ma_h, tsp, sl, ms, gb, dvt, mt);
        DBMS_OUTPUT.PUT_LINE('Them san pham moi xong');
    END IF;
    COMMIT;
END;
/
-- TEST: 
 EXEC sp_NhapSP('SP01', 'Samsung', 'Galaxy S23', 10, 'Den', 20000, 'Chiec', 'Flagship');

CREATE OR REPLACE PROCEDURE sp_xoaHangSX (th VARCHAR2) AS
    ma_h VARCHAR2(10);
BEGIN 
    SELECT MaHangSX INTO ma_h FROM HangSX WHERE TenHang = th;
    DELETE FROM SanPham WHERE MaHangSX = ma_h;
    DELETE FROM HangSX WHERE MaHangSX = ma_h;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Xoa xong hang va cac sp lien quan');
EXCEPTION WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Ten hang khong ton tai');
END;
/
 --TEST: 
 EXEC sp_xoaHangSX('Samsung');

CREATE OR REPLACE PROCEDURE sp_NhapNV (
    mnv VARCHAR2, tnv VARCHAR2, gt VARCHAR2, dc VARCHAR2, sdt VARCHAR2, mail VARCHAR2, tp VARCHAR2, flag NUMBER
) AS
BEGIN
    IF flag = 0 THEN
        UPDATE NhanVien SET TenNV = tnv, GioiTinh = gt, DiaChi = dc, SoDT = sdt, Email = mail, TenPhong = tp WHERE MaNV = mnv;
        DBMS_OUTPUT.PUT_LINE('Da update nhan vien');
    ELSE
        INSERT INTO NhanVien VALUES (mnv, tnv, gt, dc, sdt, mail, tp);
        DBMS_OUTPUT.PUT_LINE('Da them nhan vien moi');
    END IF;
    COMMIT;
END;
/
-- TEST: 
EXEC sp_NhapNV('NV01', 'Kim Thi', 'Nam', 'HCM', '0353', 'kthi@mail.com', 'Dev', 1);


CREATE OR REPLACE PROCEDURE sp_NhapHang (
    shdn VARCHAR2, msp VARCHAR2, mnv VARCHAR2, nn DATE, sln NUMBER, dgn NUMBER
) AS
    dem_sp NUMBER; dem_nv NUMBER; dem_hd NUMBER;
BEGIN
    SELECT COUNT(*) INTO dem_sp FROM SanPham WHERE MaSP = msp;
    SELECT COUNT(*) INTO dem_nv FROM NhanVien WHERE MaNV = mnv;
    
    IF dem_sp = 0 OR dem_nv = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ma SP hoac Ma NV sai roi');
        RETURN;
    END IF;

    SELECT COUNT(*) INTO dem_hd FROM PNhap WHERE SoHDN = shdn;
    IF dem_hd > 0 THEN
        UPDATE Nhap SET MaSP = msp, SoLuongN = sln, DonGiaN = dgn WHERE SoHDN = shdn AND MaSP = msp;
        DBMS_OUTPUT.PUT_LINE('Da update bang Nhap');
    ELSE
        INSERT INTO PNhap VALUES (shdn, nn, mnv);
        INSERT INTO Nhap VALUES (shdn, msp, sln, dgn);
        DBMS_OUTPUT.PUT_LINE('Da chen moi hoa don nhap');
    END IF;
    COMMIT;
END;
/
-- TEST: 
EXEC sp_NhapHang('HDN01', 'SP01', 'NV01', SYSDATE, 50, 15000);

CREATE OR REPLACE PROCEDURE sp_XuatHang (
    shdx VARCHAR2, msp VARCHAR2, mnv VARCHAR2, nx DATE, slx NUMBER
) AS
    v_sl_ton NUMBER; dem_hd NUMBER;
BEGIN
    SELECT SoLuong INTO v_sl_ton FROM SanPham WHERE MaSP = msp;
    IF v_sl_ton < slx THEN
        DBMS_OUTPUT.PUT_LINE('Khong du hang de xuat');
        RETURN;
    END IF;

    SELECT COUNT(*) INTO dem_hd FROM PXuat WHERE SoHDX = shdx;
    IF dem_hd > 0 THEN
        UPDATE Xuat SET MaSP = msp, SoLuongX = slx WHERE SoHDX = shdx AND MaSP = msp;
        DBMS_OUTPUT.PUT_LINE('Da update bang Xuat');
    ELSE
        INSERT INTO PXuat VALUES (shdx, nx, mnv);
        INSERT INTO Xuat VALUES (shdx, msp, slx);
        DBMS_OUTPUT.PUT_LINE('Da xuat hang moi');
    END IF;
    COMMIT;
EXCEPTION WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Ma SP hoac NV khong dung');
END;
/
-- TEST: 
EXEC sp_XuatHang('HDX01', 'SP01', 'NV01', SYSDATE, 5);


CREATE OR REPLACE PROCEDURE sp_XoaNV (mnv VARCHAR2) AS
    dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO dem FROM NhanVien WHERE MaNV = mnv;
    IF dem = 0 THEN
    DBMS_OUTPUT.PUT_LINE('Khong tim thay nhan vien nay');
        RETURN;
    END IF;

    DELETE FROM Xuat WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = mnv);
    DELETE FROM Nhap WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = mnv);
    DELETE FROM PXuat WHERE MaNV = mnv;
    DELETE FROM PNhap WHERE MaNV = mnv;
    DELETE FROM NhanVien WHERE MaNV = mnv;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Xoa sach se nhan vien va hoa don');
END;
/
-- TEST: 
EXEC sp_XoaNV('NV01');

CREATE OR REPLACE PROCEDURE sp_XoaSP (msp VARCHAR2) AS
    dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO dem FROM SanPham WHERE MaSP = msp;
    IF dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('San pham nay lam gi co ma xoa');
        RETURN;
    END IF;

    DELETE FROM Nhap WHERE MaSP = msp;
    DELETE FROM Xuat WHERE MaSP = msp;
    DELETE FROM SanPham WHERE MaSP = msp;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Xoa xong san pham');
END;
/
-- TEST: 
EXEC sp_XoaSP('SP01');
-- PHIEU BAI TAP 2

CREATE OR REPLACE PROCEDURE sp_ThemNhanVien (
    mnv VARCHAR2, tnv VARCHAR2, gt NVARCHAR2, dc VARCHAR2, sdt VARCHAR2, mail VARCHAR2, tp VARCHAR2, flag NUMBER, kq OUT NUMBER
) AS
    dem NUMBER;
BEGIN
    IF gt NOT IN (N'Nam', N'Nữ') THEN
        kq := 1;
        RETURN;
    END IF;

    IF flag = 0 THEN
        INSERT INTO NhanVien VALUES (mnv, tnv, gt, dc, sdt, mail, tp);
    ELSE
        UPDATE NhanVien SET TenNV = tnv, GioiTinh = gt, DiaChi = dc, SoDT = sdt, Email = mail, TenPhong = tp WHERE MaNV = mnv;
    END IF;
    
    COMMIT;
    kq := 0;
END;
/
CREATE OR REPLACE PROCEDURE sp_ThemMoiSP (
    msp VARCHAR2, th VARCHAR2, tsp VARCHAR2, sl NUMBER, ms VARCHAR2, gb NUMBER, dvt VARCHAR2, mt CLOB, flag NUMBER, kq OUT NUMBER
) AS
    v_ma_h VARCHAR2(10);
    dem_sp NUMBER;
BEGIN
    BEGIN
        SELECT MaHangSX INTO v_ma_h FROM HangSX WHERE TenHang = th;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        kq := 1;
        RETURN;
    END;

    IF sl < 0 THEN
        kq := 2;
        RETURN;
    END IF;

    IF flag = 0 THEN
        INSERT INTO SanPham VALUES (msp, v_ma_h, tsp, sl, ms, gb, dvt, mt);
    ELSE
        UPDATE SanPham SET MaHangSX = v_ma_h, TenSP = tsp, SoLuong = sl, MauSac = ms, GiaBan = gb, DonViTinh = dvt, MoTa = mt WHERE MaSP = msp;
    END IF;

    COMMIT;
    kq := 0;
END;
/

CREATE OR REPLACE PROCEDURE sp_XoaNhanVien (mnv VARCHAR2, kq OUT NUMBER) AS
    dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO dem FROM NhanVien WHERE MaNV = mnv;
    IF dem = 0 THEN
        kq := 1;
        RETURN;
    END IF;

    DELETE FROM Xuat WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = mnv);
    DELETE FROM Nhap WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = mnv);
    DELETE FROM PXuat WHERE MaNV = mnv;
    DELETE FROM PNhap WHERE MaNV = mnv;
    DELETE FROM NhanVien WHERE MaNV = mnv;
    
    COMMIT;
    kq := 0;
END;
/
CREATE OR REPLACE PROCEDURE sp_XoaSanPham (msp VARCHAR2, kq OUT NUMBER) AS
    dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO dem FROM SanPham WHERE MaSP = msp;
    IF dem = 0 THEN
        kq := 1;
        RETURN;
    END IF;

    DELETE FROM Nhap WHERE MaSP = msp;
    DELETE FROM Xuat WHERE MaSP = msp;
    DELETE FROM SanPham WHERE MaSP = msp;
    
    COMMIT;
    kq := 0;
END;
/

CREATE OR REPLACE PROCEDURE sp_NhapHangSX (
    mhsx VARCHAR2, th VARCHAR2, dc VARCHAR2, sdt VARCHAR2, mail VARCHAR2, kq OUT NUMBER
) AS
    dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO dem FROM HangSX WHERE TenHang = th;
    IF dem > 0 THEN
        kq := 1;
    ELSE
        INSERT INTO HangSX VALUES (mhsx, th, dc, sdt, mail);
        COMMIT;
        kq := 0;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE sp_NhapDuLieu (
    shdn VARCHAR2, msp VARCHAR2, mnv VARCHAR2, nn DATE, sln NUMBER, dgn NUMBER, kq OUT NUMBER
) AS
    d_sp NUMBER; d_nv NUMBER; d_hd NUMBER;
BEGIN
    SELECT COUNT(*) INTO d_sp FROM SanPham WHERE MaSP = msp;
    IF d_sp = 0 THEN kq := 1; RETURN; END IF;

    SELECT COUNT(*) INTO d_nv FROM NhanVien WHERE MaNV = mnv;
    IF d_nv = 0 THEN kq := 2; RETURN; END IF;

    SELECT COUNT(*) INTO d_hd FROM PNhap WHERE SoHDN = shdn;
    IF d_hd > 0 THEN
        UPDATE Nhap SET MaSP = msp, SoLuongN = sln, DonGiaN = dgn WHERE SoHDN = shdn AND MaSP = msp;
    ELSE
        INSERT INTO PNhap VALUES (shdn, nn, mnv);
        INSERT INTO Nhap VALUES (shdn, msp, sln, dgn);
    END IF;
    
    COMMIT;
    kq := 0;
END;
/

CREATE OR REPLACE PROCEDURE sp_XuatDuLieu (
    shdx VARCHAR2, msp VARCHAR2, mnv VARCHAR2, nx DATE, slx NUMBER, kq OUT NUMBER
) AS
    d_sp NUMBER; d_nv NUMBER; d_hd NUMBER; v_ton NUMBER;
BEGIN
    SELECT COUNT(*) INTO d_sp FROM SanPham WHERE MaSP = msp;
    IF d_sp = 0 THEN kq := 1; RETURN; END IF;

    SELECT COUNT(*) INTO d_nv FROM NhanVien WHERE MaNV = mnv;
    IF d_nv = 0 THEN kq := 2; RETURN; END IF;

    SELECT SoLuong INTO v_ton FROM SanPham WHERE MaSP = msp;
    IF slx > v_ton THEN kq := 3; RETURN; END IF;

    SELECT COUNT(*) INTO d_hd FROM PXuat WHERE SoHDX = shdx;
    IF d_hd > 0 THEN
        UPDATE Xuat SET MaSP = msp, SoLuongX = slx WHERE SoHDX = shdx AND MaSP = msp;
    ELSE
        INSERT INTO PXuat VALUES (shdx, nx, mnv);
        INSERT INTO Xuat VALUES (shdx, msp, slx);
    END IF;
    
    COMMIT;
    kq := 0;
END;
/